<?php
//
// top14server - Serveur web service RESTful
//
// Tableaux des utilisateurs à authentifier
// Ce fichier évite l'usage d'une base de données
$users = array(
   'jef'=>'jefjef',
   'bob'=>'bobbob',
   'bill'=>'billbill'
);

